<?php

    require_once 'connect.php';

    $task_id = trim($_POST['task_id'], "d");
    $div_nr = $_POST['div_nr'];
    $display_order = $_POST['newIndex'];
    $old_div = $_POST['old_div'];

    session_start();

    $user_id = $_SESSION['id'];

    $stmt2 = $conn->prepare("UPDATE tasks SET display_order = display_order + 1 WHERE user_id = '$user_id' AND div_nr = '$div_nr' AND display_order >= '$display_order'");
    
    if($stmt2->execute())
    {
        echo 'success!';
    }

    $stmt = $conn->prepare("UPDATE tasks SET display_order = display_order-1 WHERE user_id = '$user_id' AND div_nr='$old_div' AND display_order > 1 ");
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("UPDATE tasks SET div_nr = '$div_nr', display_order = '$display_order' WHERE user_id = '$user_id' AND task_id = '$task_id'");
    
    if($stmt->execute())
    {
        echo 'success!';
    }
    
    $stmt->close();


?>