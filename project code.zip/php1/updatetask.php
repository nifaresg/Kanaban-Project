<?php

    session_start();
    require_once 'connect.php';

    $content = $_POST['taskHeader'];
    $user_id = $_SESSION['id'];
    $color = $_POST['color'];
    $end = $_POST['end'];
    $start = $_POST['start'];
    $task_id = $_POST['task_id'];

    $stmt = $conn->prepare("UPDATE tasks SET content = '$content', color='$color', end='$end', start='$start' WHERE user_id = '$user_id' AND task_id = '$task_id'");
    
    if($stmt->execute())
    {
        echo 'success!';
    }
    
    $stmt->close();

?>