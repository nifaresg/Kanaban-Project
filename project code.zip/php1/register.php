<?php

    session_start();

    if(isset($_POST['email']))
    {
        //Succes!
        $everythingOK = true;

        //Check: is nickname correct?
        $username = $_POST['username'];

        //nickname lenght check
        if((strlen($username)<3)||(strlen($username)>20))
        {
            $everythingOK = false;
            $_SESSION['usernameError'] = 'Username lenght must be greater than 3 and less than 20';
        }

        //check: does nickname contains special chars?
        if(ctype_alnum($username)==false)
        {
            $everythingOK = false;
            $_SESSION['usernameError'] = "Username can't contain special chars";
        }

        //check: is email correct
        $email = $_POST['email'];
        $correctEmail = filter_var($email, FILTER_SANITIZE_EMAIL);
        
        if((filter_var($correctEmail, FILTER_VALIDATE_EMAIL)==false) || ($correctEmail!=$email))
        {
            $everythingOK = false;
            $_SESSION['emailError'] = 'Email is incorrect';
        }

        $password1 = $_POST['password1'];
        $password2 = $_POST['password2'];

        if(strlen($password1)<8)
        {
            $everythingOK = false;
            $_SESSION['passwordError'] = 'Password lenght must be greater than 8';
        }

        if($password1!=$password2)
        {
            $everythingOK = false;
            $_SESSION['passwordError'] = 'Passwords are not match';
        }

        $hashedPassword = password_hash($password1, PASSWORD_DEFAULT);

        if(!isset($_POST['statue']))
        {
            $everythingOK = false;
            $_SESSION['statueError'] = 'Please accept site statue';
        }

        require_once 'connect.php';
        mysqli_report(MYSQLI_REPORT_STRICT);

        try
        {
            $connection = new mysqli($host, $db_user, $db_password, $db_name); 
            if($connection->connect_errno!=0)
            {
                throw new Exception(mysqli_connect_errno());
            }
            else
            {
                $resultEmail = $connection->query("SELECT id FROM users WHERE email='$email'");

                if (!$resultEmail) {throw new Exception($connection->error);}

                $how_many_emails = $resultEmail->num_rows;

                if($how_many_emails>0)
                {
                    $everythingOK = false;
                    $_SESSION['emailError'] = 'Email is alredy taken :/';
                }

                $resultUsername = $connection->query("SELECT id FROM users WHERE username='$username'");
                
                if (!$resultUsername) {throw new Exception($connection->error);}

                $how_many_usernames = $resultUsername->num_rows;

                if($how_many_usernames>0)
                {
                    $everythingOK = false;
                    $_SESSION['usernameError'] = 'Username is alredy taken :/';
                }

                if($everythingOK == true)
                {
                    if($connection->query("INSERT INTO users VALUES (NULL, '$username', '$hashedPassword', '$email', 100)"))
                    {
                        $_SESSION['registerConfirmed'] = true;
                        $_SESSION['loginError'] = false;
                        header('location: welcome.php');
                    }
                    else
                    {
                        throw new Exception($connection->error);
                    }
                }

                $connection->close();
            }
        }

        catch(Exception $e)
        {
            echo '<span style="color: red"> Server error :c </span>';
            //echo $e;
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Registration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="Styles/loginpage.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
</head>

<body style="font-family: 'Montserrat', sans-serif;">
<div style="width: 100%; text-align: center; margin-top: 18vh;">
    <h1 style="color: seagreen; ">Registration<a style="color: grey;">!</a></h1>
    <br>
    <form method="post">
        <input class="login__input" type="text" placeholder="username" name="username">

        <?php
            if(isset($_SESSION['usernameError']))
            {
                echo '<br> <a style="color: red">'.$_SESSION["usernameError"].'</a>';
                unset($_SESSION['usernameError']);
            }
        ?>

        <br/><br/>
        <input  class="login__input" type="text" placeholder="e-mail" name="email" >
        <?php
            if(isset($_SESSION['emailError']))
            {
                echo '<br> <a style="color: red">'.$_SESSION["emailError"].'</a>';
                unset($_SESSION['emailError']);
            }
        ?>
        <br/><br>
        <input class="login__input" type="password" placeholder="password" name="password1">
        <br/><br/>
        <input class="login__input" type="password" placeholder="repeat password" name="password2">
        
        <?php
            if(isset($_SESSION['passwordError']))
            {
                echo '<br> <a style="color: red">'.$_SESSION["passwordError"].'</a>';
                unset($_SESSION['passwordError']);
            }
        ?>
        
        <br/><br/><br>
        <label>
            <input type="checkbox" name='statue'> Akceptuje regulamin
        </label>

         <?php
            if(isset($_SESSION['statueError']))
            {
                echo '<br> <a style="color: red">'.$_SESSION["statueError"].'</a>';
                unset($_SESSION['statueError']);
            }
        ?>

        <br><br>
        <?php
            if(isset($_SESSION['botError']))
            {
                echo '<br> <a style="color: red">'.$_SESSION["botError"].'</a><br>';
                unset($_SESSION['botError']);
            }
        ?>
        <br>
        <input type="submit" class="btn btn-success" value="Register">
    </form>
    </div>
</body>
</html>