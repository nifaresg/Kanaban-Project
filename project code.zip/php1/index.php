<?php
    session_start();

    if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']=true)
    {
        header('location: userPage.php');
        exit();
    }
?>

<!DOCTYPE html>
<html lang="eng">

<head>
<meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Task Menager</title>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="Styles/loginpage.css?version=1"/>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>

<body style="font-family: 'Montserrat', sans-serif;">
    
    <div class='loginScreen' style='text-align: center; margin-top: 18vh;'>
        <h1 style="color: seagreen">Welcome<a style="color: grey;">!</a></h1>
        <form action="login.php" method="post">
            <input class="login__input"type="text" placeholder="username" name="username" style='text-align: center;'>
            <br/><br/>
            <input class="login__input" type="password" placeholder="password" name="password" style='text-align: center;'>
            <br/><br/>
            <input type="submit" class="btn btn-success" value="Login" style="width: 100px" >
            <br><br>
            You don't have an account? Register <a href="register.php" style="text-decoration: none; color: seagreen;">here</a>!
        </form>

        <?php

            if(isset($_SESSION['loginError']) && $_SESSION['loginError'] = '<span style="color: red">Nie udalo sie zalogowac :/</span>')
            {
                echo "<span style='color: red;'>Login failed</span>";
            }
        ?>

    </div>
</body>

</html>