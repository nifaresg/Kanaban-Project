<?php
    session_start();

    require_once "connect.php";
    $connection = @new mysqli($host, $db_user, $db_password, $db_name); 

    if($connection->connect_errno!=0)
    {
        echo "error: ".$connection->connect_errno;
    }
    else
    {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $username = htmlentities($username, ENT_QUOTES, "utf-8");
        $password = htmlentities($password, ENT_QUOTES, "utf-8");

        if($result = @$connection->query(sprintf(
            "SELECT * FROM users WHERE username='%s' AND password='%s'",
            mysqli_real_escape_string($connection, $username), mysqli_real_escape_string($connection, $password))))
        {
            $how_much_users = $result->num_rows;

            if($how_much_users>0)
            {
                $_SESSION['loggedin'] = true;

                $info = $result->fetch_assoc();
                $_SESSION['id'] = $info['id'];
                $_SESSION['username'] = $info['username'];
                
                unset($_SESSION['loginError']);
                $result->free();
                header("location: userPage.php");
            }
            else
            {
                $_SESSION['loginError'] = '<span style="color: red">Nie udalo sie zalogowac :/</span>';
                header('location: index.php');
            }
        }

        $connection->close();
    }
?>