$(document).ready(function(){

    $('.sortable_list').sortable({ revert: true, cursor: 'pointer', containment: 'window',
        connectWith: ".connectedSortable",
        start: function(event, ui) {
            $(this).attr('data-previndex', ui.item.index());
        },
        receive: function(event, ui){

            if(this.id == "d1")
            {
                var div_nr = 1;
            }
            else if(this.id == "d2")
            {
                var div_nr = 2;
            }
            else if(this.id == "d3")
            {
                var div_nr = 3;
            }
            else if(this.id == "d4")
            {
                var div_nr = 4;
            }

            var task_id = $(ui.item).attr("id");
            var newIndex = ui.item.index()+1;
            var old_div = ui.sender[0].id;
            

            $.ajax({
                type: 'POST',
                url: 'sort.php',
                data: {task_id:task_id, div_nr:div_nr, newIndex:newIndex, old_div:old_div},
            })

            setTimeout(function(){
                $("#d"+div_nr).load(" #d"+div_nr);
                $("#"+ui.sender[0].id).load(" #"+ui.sender[0].id);
            }, 100);

            
        },
        remove: function(event, ui){

            if(this.id == "d1")
            {
                var div_nr = 1;
            }
            else if(this.id == "d2")
            {
                var div_nr = 2;
            }
            else if(this.id == "d3")
            {
                var div_nr = 3;
            }
            else if(this.id == "d4")
            {
                var div_nr = 4;
            }

            var task_id = $(ui.item).attr("id");
            var old_index = $(this).attr('data-previndex')+1;
            

            $.ajax({
                type: 'POST',
                url: 'sortremove.php',
                data: {div_nr:div_nr, task_id:task_id, old_index:old_index},
            })

            setTimeout(function(){
                $("#d"+div_nr).load(" #d"+div_nr);
                $("#"+ui.sender[0].id).load(" #"+ui.sender[0].id);
            }, 100);

            
        }
    
    });
    

});