function updatetask(clicked_id){ 

    var task_id = clicked_id;

    $("#form2").submit(function(e){
    e.preventDefault();

    if (document.getElementById('inlineRadio6').checked) {
        var color = document.getElementById('inlineRadio6').value;
    }
    else if (document.getElementById('inlineRadio7').checked) {
        var color = document.getElementById('inlineRadio7').value;
      }
    else if (document.getElementById('inlineRadio8').checked) {
        var color = document.getElementById('inlineRadio8').value;
      }
    else  if (document.getElementById('inlineRadio9').checked) {
        var color = document.getElementById('inlineRadio9').value;
      }
    else  if (document.getElementById('inlineRadio10').checked) {
        var color = document.getElementById('inlineRadio10').value;
      }
    else { var color = 1; }

        $.ajax({
            url: 'updatetask.php',
            type: 'POST',
            data: {taskHeader: $('#taskHeader2').val(), color: color, end:$('#EndAt2').val(), start:$('#StartingAt2').val(), task_id: task_id},
            success: function(){
                $("#d1").load(" #d1");
                $("#d2").load(" #d2");
                $("#d3").load(" #d3");
                $("#d4").load(" #d4");
                $('form').get(0).reset();
                $("#myModal2").removeClass("in");
                $(".modal-backdrop").remove();
                $('body').removeClass('modal-open');
                $('body').css('padding-right', '');
                $("#myModal2").hide();
            }
        })
    });  

    
    
    }