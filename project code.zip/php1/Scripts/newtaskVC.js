  
function newtask(clicked_id){ 


    if(clicked_id == "taskAdder1")
    {
        var div_nr = 1;
        var div_id = "d1";
    }
    else if(clicked_id == "taskAdder2")
    {
        var div_nr = 2;
        var div_id = "d2";
    }
    else if(clicked_id == "taskAdder3")
    {
        var div_nr = 3;
        var div_id = "d3";
    }
    else if(clicked_id == "taskAdder4")
    {
        var div_nr = 4;
        var div_id = "d4";
    }

    

    $("#form1").submit(function(e){
    e.preventDefault();

    if (document.getElementById('inlineRadio1').checked) {
        var color = document.getElementById('inlineRadio1').value;
    }
    else if (document.getElementById('inlineRadio2').checked) {
        var color = document.getElementById('inlineRadio2').value;
      }
    else if (document.getElementById('inlineRadio3').checked) {
        var color = document.getElementById('inlineRadio3').value;
      }
    else  if (document.getElementById('inlineRadio4').checked) {
        var color = document.getElementById('inlineRadio4').value;
      }
    else  if (document.getElementById('inlineRadio5').checked) {
        var color = document.getElementById('inlineRadio5').value;
      }
    else { var color = 1; }

        $.ajax({
            url: 'insertTask.php',
            type: 'POST',
            data: {taskHeader: $('#taskHeader').val(), div_nr: div_nr, color: color, end:$('#EndAt').val(), start:$('#StartingAt').val()},
            success: function(){
                $("#"+div_id).load(" #"+div_id);
                $('form').get(0).reset();
                $("#myModal1").removeClass("in");
                $(".modal-backdrop").remove();
                $('body').removeClass('modal-open');
                $('body').css('padding-right', '');
                $("#myModal1").hide();
            }
        })
    });  

    
    
    }