<?php

    include 'connect.php';
    
    $div_nr = $_POST['div_nr'];

    session_start();

    $user_id = $_SESSION['id'];
    $task_id = $_POST['task_id'];
    $display_order = $_POST['old_index'];



    $stmt = $conn->prepare("UPDATE tasks SET display_order = display_order-1 WHERE user_id = '$user_id' AND div_nr='$div_nr' AND display_order > 1 ");
    $stmt->execute();
    $stmt->close();

    $stmt2 = $conn->prepare("UPDATE tasks SET display_order = display_order-1 WHERE user_id = '$user_id' AND task_id='$task_id' AND display_order > 1");
    $stmt2->execute();
    $stmt2->close();

?>