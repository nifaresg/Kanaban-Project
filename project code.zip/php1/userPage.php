<?php

    include 'connect.php';
    session_start();

    if(!isset($_SESSION['loggedin']))
    {
        header('location: index.php');
        unset($_SESSION['loginError']);
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Tasks!</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="Styles/mainpage.css?version=8" />
    <script src="main.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>

    <script type="text/javascript" src="Scripts/newtaskVC.js"></script>
    <script type="text/javascript" src="Scripts/sortableVC.js"></script>

    <script type="text/javascript" src="Scripts/taskeditVC.js"></script>
   

</head>
<body>
    <div class='wrapper'>



        <!-- DIV NR 1  -->





        <div class='task-column'  style="float: left;">

            <div class='task-column__header'>Not <b>Started</b></div>

            <div class="sortable_list connectedSortable" id="d1">

                <?php
                    $userID = $_SESSION['id'];
                    $sql = "SELECT * FROM Tasks WHERE user_id=$userID AND div_nr=1 ORDER BY display_order ASC";
                    $result = mysqli_query($conn, $sql);

                    if(mysqli_num_rows($result)>0)
                    {
                        while($row = mysqli_fetch_assoc($result))
                        {
                            $task_id = $row['task_id'];

                            if($row['color']==5)
                            {
                                $color = 'crimson';
                            }
                            else if($row['color']==2)
                            {
                                $color = 'seagreen';
                            }
                            else if($row['color']==3)
                            {
                                $color = 'gold';
                            }
                            else if($row['color']==4)
                            {
                                $color = 'Coral';
                            }
                            else if($row['color']==1)
                            {
                                $color = 'Grey';
                            }

                            $startMONTH = substr($row['start'], -5, -3);
                            $startDAY = substr($row['start'], 8, 2);
                            
                            $endMONTH = substr($row['end'], -5, -3);
                            $endDAY = substr($row['end'], 8, 2);

                            echo "<div id=$task_id  onclick='updatetask(this.id)' data-toggle='modal' data-target='#myModal2' class=\"task-div\"  style=\"border-left: 4px $color solid\">";
                            echo "<div class='task-content__header'>";
                            echo $row['content'];
                            echo "</div>";
                            echo "<div class=\"task-content__date\" >";
                            echo $startDAY;
                            echo " <b  style=\"color: $color\">"; 
                            echo $startMONTH;
                            echo "</b>";

                            echo "&emsp; -&emsp; ";

                            echo $endDAY;
                            echo " <b  style=\"color: $color\">"; 
                            echo $endMONTH;
                            echo "</b>";
                            echo "</div>";
                            echo "</div>";

                        }
                    }
                    else
                    {
                        echo "<div class=\"task-content__alert\">";
                        echo "You have no tasks";
                        echo "</div>";
                    }
                ?>

                

            </div>

            <button type="button" class="btn btn-default" id="taskAdder1" data-toggle='modal' data-target='#myModal1' onClick="newtask(this.id)"   style='margin-top: 12px;'><b>+</b> New <b>Task</b></button>
        </div>

        <!-- DIV NR 2  -->





        <div class='task-column'  style="float: left;" >

            <div class='task-column__header'><b>Ready</b></div>

            <div class="sortable_list connectedSortable" id="d2">
            <?php
                    $userID = $_SESSION['id'];
                    $sql = "SELECT * FROM Tasks WHERE user_id=$userID AND div_nr=2 ORDER BY display_order ASC";
                    $result = mysqli_query($conn, $sql);

                    if(mysqli_num_rows($result)>0)
                    {
                        while($row = mysqli_fetch_assoc($result))
                        {
                            $task_id = $row['task_id'];

                            if($row['color']==5)
                            {
                                $color = 'crimson';
                            }
                            else if($row['color']==2)
                            {
                                $color = 'seagreen';
                            }
                            else if($row['color']==3)
                            {
                                $color = 'gold';
                            }
                            else if($row['color']==4)
                            {
                                $color = 'Coral';
                            }
                            else if($row['color']==1)
                            {
                                $color = 'Grey';
                            }
                            
                            $startMONTH = substr($row['start'], -5, -3);
                            $startDAY = substr($row['start'], 8, 2);
                            
                            $endMONTH = substr($row['end'], -5, -3);
                            $endDAY = substr($row['end'], 8, 2);

                            echo "<div id=$task_id  onclick='updatetask(this.id)' data-toggle='modal' data-target='#myModal2' class=\"task-div\"  style=\"border-left: 4px $color solid\">";
                            echo "<div class='task-content__header'>";
                            echo $row['content'];
                            echo "</div>";
                            echo "<div class=\"task-content__date\" >";

                            echo $startDAY;
                            echo " <b  style=\"color: $color\">"; 
                            echo $startMONTH;
                            echo "</b>";

                            echo "&emsp; -&emsp; ";

                            echo $endDAY;
                            echo " <b  style=\"color: $color\">"; 
                            echo $endMONTH;
                            echo "</b>";
                            echo "</div>";
                            echo "</div>";

                        }
                    }
                    else
                    {
                        echo "<div draggable='true'  style='color: grey; font-size: 18px; text-align: center;'>";
                        echo "You have no tasks";
                        echo "</div>";
                    }
                ?>
            </div>
            
            <button type="button" class="btn btn-default" id="taskAdder2" data-toggle='modal' data-target='#myModal1' onClick="newtask(this.id)"   style='margin-top: 12px;'><b>+</b> New <b>Task</b></button>
        </div>



        



        <!-- DIV NR 3  -->







        <div class='task-column'  style="float: left;">

            <div class='task-column__header'>In <b>progress</b></div>

            <div class="sortable_list connectedSortable" id="d3">
            <?php
                    $userID = $_SESSION['id'];
                    $sql = "SELECT * FROM Tasks WHERE user_id=$userID AND div_nr=3 ORDER BY display_order ASC";
                    $result = mysqli_query($conn, $sql);

                    if(mysqli_num_rows($result)>0)
                    {
                        while($row = mysqli_fetch_assoc($result))
                        {
                            $task_id = $row['task_id'];

                            if($row['color']==5)
                            {
                                $color = 'crimson';
                            }
                            else if($row['color']==2)
                            {
                                $color = 'seagreen';
                            }
                            else if($row['color']==3)
                            {
                                $color = 'gold';
                            }
                            else if($row['color']==4)
                            {
                                $color = 'Coral';
                            }
                            else if($row['color']==1)
                            {
                                $color = 'Grey';
                            }

                            $startMONTH = substr($row['start'], -5, -3);
                            $startDAY = substr($row['start'], 8, 2);
                            
                            $endMONTH = substr($row['end'], -5, -3);
                            $endDAY = substr($row['end'], 8, 2);

                            echo "<div id=$task_id  onclick='updatetask(this.id)' data-toggle='modal' data-target='#myModal2' class=\"task-div\"  style=\"border-left: 4px $color solid\">";
                            echo "<div class='task-content__header'>";
                            echo $row['content'];
                            echo "</div>";
                            echo "<div class=\"task-content__date\" >";

                            echo $startDAY;
                            echo " <b  style=\"color: $color\">"; 
                            echo $startMONTH;
                            echo "</b>";

                            echo "&emsp; -&emsp; ";

                            echo $endDAY;
                            echo " <b  style=\"color: $color\">"; 
                            echo $endMONTH;
                            echo "</b>";
                            echo "</div>";
                            echo "</div>";

                        }
                    }
                    else
                    {
                        echo "<div draggable='true'  style='color: grey; font-size: 18px; text-align: center;'>";
                        echo "You have no tasks";
                        echo "</div>";
                    }
                ?>
            </div>

<button type="button" class="btn btn-default" id="taskAdder3" data-toggle='modal' data-target='#myModal1' onClick="newtask(this.id)"   style='margin-top: 12px;'><b>+</b> New <b>Task</b></button>        </div>
        





        <!-- DIV NR 4  -->








        <div class='task-column'  style="float: left;">

                <div class='task-column__header'>Under <b>review</b></div>

                <div class="sortable_list connectedSortable" id="d4">

                        <?php
                    $userID = $_SESSION['id'];
                    $sql = "SELECT * FROM Tasks WHERE user_id=$userID AND div_nr=4 ORDER BY display_order ASC";
                    $result = mysqli_query($conn, $sql);

                    if(mysqli_num_rows($result)>0)
                    {
                        while($row = mysqli_fetch_assoc($result))
                        {
                            $task_id = $row['task_id'];

                            if($row['color']==5)
                            {
                                $color = 'crimson';
                            }
                            else if($row['color']==2)
                            {
                                $color = 'seagreen';
                            }
                            else if($row['color']==3)
                            {
                                $color = 'gold';
                            }
                            else if($row['color']==4)
                            {
                                $color = 'Coral';
                            }
                            else if($row['color']==1)
                            {
                                $color = 'Grey';
                            }
                            
                            $startMONTH = substr($row['start'], -5, -3);
                            $startDAY = substr($row['start'], 8, 2);
                            
                            $endMONTH = substr($row['end'], -5, -3);
                            $endDAY = substr($row['end'], 8, 2);

                            echo "<div id=$task_id  onclick='updatetask(this.id)' data-toggle='modal' data-target='#myModal2' class=\"task-div\"  style=\"border-left: 4px $color solid\">";
                            echo "<div class='task-content__header'>";
                            echo $row['content'];
                            echo "</div>";
                            echo "<div class=\"task-content__date\" >";

                            echo $startDAY;
                            echo " <b  style=\"color: $color\">"; 
                            echo $startMONTH;
                            echo "</b>";

                            echo "&emsp; -&emsp; ";

                            echo $endDAY;
                            echo " <b  style=\"color: $color\">"; 
                            echo $endMONTH;
                            echo "</b>";
                            echo "</div>";
                            echo "</div>";

                        }
                    }
                    else
                    {
                        echo "<div  style='color: grey; font-size: 18px; text-align: center;'>";
                        echo "You have no tasks";
                        echo "</div>";
                    }
                ?>

                </div>

<button type="button" class="btn btn-default" id="taskAdder4" data-toggle='modal' data-target='#myModal1' onClick="newtask(this.id)"   style='margin-top: 12px;'><b>+</b> New <b>Task</b></button>
        </div>

    <!-- Modal -->
    <div class="modal fade" id="myModal1" role="dialog"  style="text-align: center;">

                    <div class="modal-dialog modal-dialog-centered">
                    
                        <!-- Modal content-->
                        <div class="modal-content">

                            <div class="modal-header">

                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title"  style="float: left;"><b>Enter</b> task properties below</h4>

                            </div>


                            <div class="modal-body">

                                <form method="post" action="insertTask.php" id="form1">

                                    <span  style="float: left; font-size: 14px">Task header: </span> <input class="form__text-input" id="taskHeader" type="text" autocomplete="off" name="taskDescription">
                                    <br><br>
                                    <span  style="float: left; font-size: 14px">Starting At: </span> <input class="form__text-input" id="StartingAt" type="date" autocomplete="off" name="taskDescription">
                                    <br><br>
                                    <span  style="float: left; font-size: 14px">End at:</span> <input class="form__text-input" id="EndAt" type="date" autocomplete="off" name="taskDescription">
                                    <br><br>
                                    <span  style="float: left; font-size: 14px">Label color: </span>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio1" value="1"> <b  style="color: Grey;"> Default</b>
                                    </label>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio2" value="5"> <b  style="color: crimson;"> Red</b>
                                    </label>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio3" value="2"> <b  style="color: seagreen;"> Green</b>
                                    </label>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio4" value="3"> <b  style="color: gold;"> Yellow</b>
                                    </label>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio5" value="4"> <b  style="color: coral;"> Orange</b>
                                    </label>
                                    
                                    
                                </form>
                            </div>


                            <div class="modal-footer">

                                    <button type="button" id="closeModalBtn"class="btn btn-default" data-dismiss="modal"  style="color: grey">Close</button>
                                    <button class="btn btn-default" id="new-task-btn" form="form1" ><b>Save</b></button>
                            </div>
                        </div>

                    </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="myModal2" role="dialog"  style="text-align: center;">

                    <div class="modal-dialog modal-dialog-centered">
                    
                        <!-- Modal content-->
                        <div class="modal-content">

                            <div class="modal-header">

                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title"  style="float: left;"><b>Update</b> task properties below</h4>

                            </div>


                            <div class="modal-body">

                                <form method="post" action="updatetask.php" id="form2">

                                    <span  style="float: left; font-size: 14px">Task header: </span> <input class="form__text-input" id="taskHeader2" type="text"  name="taskDescription">
                                    <br><br>
                                    <span  style="float: left; font-size: 14px">Starting At: </span> <input class="form__text-input" id="StartingAt2" type="date" name="taskDescription">
                                    <br><br>
                                    <span  style="float: left; font-size: 14px">End at:</span> <input class="form__text-input" id="EndAt2" type="date" name="taskDescription">
                                    <br><br>
                                    <span  style="float: left; font-size: 14px">Label color: </span>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio6" value="1"> <b  style="color: Grey;"> Default</b>
                                    </label>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio7" value="5"> <b  style="color: crimson;"> Red</b>
                                    </label>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio8" value="2"> <b  style="color: seagreen;"> Green</b>
                                    </label>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio9" value="3"> <b  style="color: gold;"> Yellow</b>
                                    </label>
                                    <label class="radio-inline">
                                    <input type="radio" name="options" id="inlineRadio10" value="4"> <b  style="color: coral;"> Orange</b>
                                    </label>
                                    
                                    
                                </form>
                            </div>


                            <div class="modal-footer">

                                    <button type="button" id="closeModalBtn"class="btn btn-default" data-dismiss="modal"  style="color: grey">Close</button>
                                    <button class="btn btn-default" id="updatetaskbtn" form="form2" ><b>Update</b></button>
                            </div>

                        </div>

                    </div>
    </div>



</body>
</html