<?php

require_once 'connect.php';

    $task_id = trim($_POST['task_id'], "d");

    session_start();


    $stmt = $conn->prepare("DELETE FROM tasks WHERE task_id=$task_id");
    
    if($stmt->execute())
    {
        echo 'success!';
    }
    
    $stmt->close();

?>