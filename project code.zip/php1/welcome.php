<?php

    session_start();

    if(!isset($_SESSION['registerConfirmed']))
    {

        header('location: index.php');
        exit();
    }
    else
    {
        $_SESSION['loginError'] = false;
        unset($_SESSION['registerConfirmed']);
    }
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Welcome Site</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
    <h1> Thank you for your register </h1>
    Log in <a href='login.php'>here</a>
</body>
</html>