<?php

    session_start();

    $content = $_POST['taskHeader'];
    $user_id = $_SESSION['id'];
    $div_nr = $_POST['div_nr'];
    $color = $_POST['color'];
    $end = $_POST['end'];
    $start = $_POST['start'];

        $con = new mysqli('localhost', 'root', '', 'php1');

        if($con->connect_error)
        {
            echo 'database connection error';
        }

        $stmt = $con->prepare("INSERT INTO tasks(content, user_id, div_nr, color, start, end) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sisiss", $content, $user_id, $div_nr, $color, $start, $end);

        if($stmt->execute())
        {
            echo 'success';
        }
        else
        {
            echo 'failure';
        }
    
 ?>