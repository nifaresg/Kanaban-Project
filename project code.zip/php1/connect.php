<?php
    $host = "localhost";
    $db_user = "root";
    $db_password = "";
    $db_name = "php1";

    $conn = mysqli_connect($host, $db_user, $db_password, $db_name);
?>